import type { Metadata } from "next";
import "./index.css";

// import ReactQueryProvider from "@/components/ReactQueryProvider";
import { UserProvider } from "@auth0/nextjs-auth0/client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Course Compass",
  description: "TODO",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <UserProvider>
          {/* <ReactQueryProvider> */}
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">{children}</main>
            <Footer />
          </div>
          {/* </ReactQueryProvider> */}
        </UserProvider>
      </body>
    </html>
  );
}
