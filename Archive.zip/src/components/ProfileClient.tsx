"use client";

import { useUser } from "@auth0/nextjs-auth0/client";
import Image from "next/image";

export default function ProfileClient() {
  const { user, error, isLoading } = useUser();

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>{error.message}</div>;

  return (
    user && (
      <div className="flex flex-col items-center p-4">
        <Image
          src={user.picture || ""}
          alt={user.name || "User profile"}
          width={100}
          height={100}
          className="rounded-full"
        />
        <h2 className="mt-4 text-xl font-bold">{user.name}</h2>
        <p className="text-gray-600">{user.email}</p>
      </div>
    )
  );
}
